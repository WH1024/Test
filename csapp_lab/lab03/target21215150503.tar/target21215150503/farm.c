/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_286(unsigned x)
{
    return x + 3347662959U;
}

void setval_173(unsigned *p)
{
    *p = 3347662853U;
}

unsigned getval_158()
{
    return 3347663368U;
}

unsigned getval_296()
{
    return 2425393240U;
}

unsigned addval_293(unsigned x)
{
    return x + 2425393752U;
}

void setval_470(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_209()
{
    return 3281031256U;
}

unsigned getval_281()
{
    return 2425362569U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_137(unsigned *p)
{
    *p = 2429659459U;
}

unsigned addval_444(unsigned x)
{
    return x + 2445445505U;
}

unsigned addval_180(unsigned x)
{
    return x + 3281047945U;
}

unsigned getval_265()
{
    return 3268512213U;
}

unsigned addval_319(unsigned x)
{
    return x + 2425409945U;
}

void setval_424(unsigned *p)
{
    *p = 3229142665U;
}

void setval_357(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_123()
{
    return 3263759213U;
}

unsigned getval_436()
{
    return 2447411528U;
}

unsigned addval_349(unsigned x)
{
    return x + 3767094281U;
}

void setval_162(unsigned *p)
{
    *p = 3281109641U;
}

unsigned addval_263(unsigned x)
{
    return x + 3229929101U;
}

unsigned getval_482()
{
    return 3525886601U;
}

void setval_135(unsigned *p)
{
    *p = 3682124425U;
}

void setval_489(unsigned *p)
{
    *p = 3767093323U;
}

unsigned addval_459(unsigned x)
{
    return x + 2429454808U;
}

void setval_152(unsigned *p)
{
    *p = 3675836809U;
}

unsigned getval_327()
{
    return 2428668837U;
}

unsigned getval_139()
{
    return 3352201660U;
}

void setval_360(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_233(unsigned x)
{
    return x + 3229143433U;
}

unsigned addval_487(unsigned x)
{
    return x + 3675836809U;
}

void setval_309(unsigned *p)
{
    *p = 1656999561U;
}

unsigned getval_441()
{
    return 3286272264U;
}

unsigned getval_237()
{
    return 3281047945U;
}

void setval_396(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_367()
{
    return 3223899785U;
}

unsigned getval_474()
{
    return 2425409153U;
}

unsigned getval_300()
{
    return 2495777150U;
}

void setval_462(unsigned *p)
{
    *p = 3263780240U;
}

unsigned addval_467(unsigned x)
{
    return x + 2425540233U;
}

unsigned getval_341()
{
    return 3269495112U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
